# Streetwise Dice Roller - Proof of Concept

A fully functional dice roller implementing the Year Zero Engine mechanics for **Streetwise**, a Victorian street urchin RPG.

## Features Implemented

### ✅ Core Mechanics
- **Dice Pool Calculation**: Attribute + Skill + Modifier + Scene Strain
- **Visual Dice Distinction**: Regular dice (cream) vs Strain dice (crimson)
- **Success/Bane Counting**: 6s = successes, 1s = banes
- **Push Roll Functionality**: Reroll non-6/non-1 dice with consequences
- **Scene Strain Tracking**: Party-wide resource that affects all rolls
- **Scene Panic System**: Triggers when Strain dice roll banes

### 🎨 Victorian Aesthetic
- Aged parchment background
- Dark ink typography
- Crimson and brass accents
- Period-appropriate styling

### 🎲 Dice Mechanics

**Regular Dice (Cream)**:
- Represent Attribute + Skill + Modifiers
- Count toward successes and banes
- Banes increase Scene Strain when pushed

**Strain Dice (Crimson)**:
- Added automatically based on Scene Strain Points
- Make success easier but riskier
- Banes trigger Scene Panic table

**Pushing Rolls**:
- Keep all 6s and 1s
- Reroll all other dice
- Total banes from BOTH rolls add to Scene Strain
- Some talents allow pushing twice

**Scene Panic**:
- Triggered by banes on Strain dice
- Roll d6 + current Strain
- Results range from "Keep it together" to "Chaos"
- May add additional Strain Points

## Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

The app will open at `http://localhost:3000`

## How to Use

### Basic Roll
1. Set your **Attribute** (0-10)
2. Set your **Skill** (0-10)
3. Add any **Modifier** (-5 to +5)
4. Click **Roll Dice**

### Pushing a Roll
1. After rolling, if you didn't get enough successes
2. Click **Push Roll** button
3. Non-6/non-1 dice are rerolled
4. Scene Strain increases by total banes (original + pushed)
5. If Strain dice show banes, Scene Panic triggers

### Scene Strain
- Starts at 0 each scene
- Increases when players Push rolls
- Adds dice to ALL subsequent rolls
- Higher strain = easier success but more dangerous
- Color-coded danger levels:
  - **Green (0-3)**: Safe
  - **Yellow (4-6)**: Moderate risk
  - **Orange (7-9)**: High risk
  - **Red (10+)**: Critical danger

### Talents
- Check **Can Push Twice** to simulate talents like "Light Fingered"
- Allows a second push on the same roll

## Testing Scenarios

### Scenario 1: Basic Successful Roll
```
Attribute: 3, Skill: 2, Modifier: 0, Strain: 0
Expected: 5 dice rolled, at least one 6 = success
```

### Scenario 2: Failed Roll → Push
```
Attribute: 2, Skill: 1, Modifier: 0, Strain: 0
1. Roll 3 dice, get no 6s
2. Click Push Roll
3. Non-6/non-1 dice rerolled
4. If any banes rolled, Strain increases
```

### Scenario 3: High Strain with Scene Panic
```
Attribute: 3, Skill: 2, Modifier: 0, Strain: 5
1. Roll 5 regular + 5 strain dice
2. Push the roll
3. If any Strain dice show 1s, Scene Panic triggers
4. See panic roll result (d6 + 5)
5. Strain increases by total banes + panic effect
```

### Scenario 4: Double Push (Talent)
```
Enable "Can Push Twice" checkbox
1. Make initial roll
2. Push once
3. Push again (button available if talent enabled)
4. Total banes from all three rolls add to Strain
```

### Scenario 5: Negative Modifier
```
Attribute: 2, Skill: 1, Modifier: -2, Strain: 0
Expected: Minimum 1 die rolled (negative pools default to 1)
```

## Code Architecture

```
src/
├── types/
│   └── dice.ts              # TypeScript interfaces and constants
├── utils/
│   └── diceRoller.ts        # Core dice mechanics logic
├── components/
│   ├── DiceDisplay.tsx      # Dice visualization components
│   ├── DiceDisplay.css      # Dice styling
│   ├── DiceRoller.tsx       # Main roller component
│   └── DiceRoller.css       # Main roller styling
├── App.tsx                  # App entry point
├── App.css                  # Base app styles
└── main.tsx                 # React DOM root
```

### Key Functions

**`performRoll(params)`**
- Initial roll with given parameters
- Returns DiceRoll object with results

**`pushRoll(originalRoll, canPushTwice)`**
- Pushes an existing roll
- Rerolls non-6/non-1 dice
- Calculates total banes across both rolls

**`checkScenePanic(roll, currentStrain)`**
- Determines if panic triggers (banes on strain dice)
- Rolls d6 + strain for panic table
- Returns effect description and strain increase

**`calculateNewStrain(currentStrain, roll)`**
- Adds total banes to current strain
- Returns new strain value

## Validation Checklist

Test each of these to verify mechanics work correctly:

- [ ] Dice pool calculates correctly (Attr + Skill + Mod + Strain)
- [ ] Regular dice display in cream color
- [ ] Strain dice display in crimson color
- [ ] 6s highlighted as successes (green border)
- [ ] 1s highlighted as banes (red border)
- [ ] Success count accurate (count all 6s)
- [ ] Bane count accurate (count all 1s, separated by type)
- [ ] Push button only appears after initial roll
- [ ] Push rerolls only non-6/non-1 dice
- [ ] Total banes count from both original + pushed rolls
- [ ] Scene Strain increases by total banes after push
- [ ] Scene Panic triggers when Strain dice show banes
- [ ] Panic roll = d6 + current Strain (before increase)
- [ ] Panic table lookup correct
- [ ] Additional strain from panic effect applied
- [ ] "Can Push Twice" enables second push
- [ ] Second push works correctly
- [ ] Roll history displays last 5 rolls
- [ ] Reset Scene button clears strain to 0
- [ ] Minimum 1 die enforced (negative pools)

## Known Issues / Limitations

This is a proof-of-concept, so some features are simplified:

1. **No Persistence**: Strain resets on page reload
2. **No Multi-Player**: This is single-user only
3. **No Character Sheet**: Just the dice roller
4. **Simplified Talents**: Only "Can Push Twice" implemented
5. **No Sound Effects**: Silent rolling
6. **No Animations**: Instant results (no rolling animation)

These will be addressed in the full Owlbear extension.

## Next Steps

Once this POC is validated:

1. **Integrate with Owlbear SDK**
   - Use OBR room metadata for Scene Strain (shared state)
   - Broadcast rolls to all players
   - Link to character sheets

2. **Add Character Sheet**
   - Store attributes, skills, talents
   - Click-to-roll from sheet
   - Conditions tracking

3. **Enhanced UI**
   - Dice roll animations
   - Sound effects
   - Better mobile support

4. **Reference Tools**
   - Scene Panic table viewer
   - Talent descriptions
   - Combat maneuvers

## Questions or Issues?

If something doesn't work as expected, check:

1. Are you using the correct dice counts?
2. Did the push actually reroll non-6/non-1 dice?
3. Is Scene Strain updating correctly?
4. Does Scene Panic trigger only on Strain dice banes?

## License

This is a proof-of-concept for the Streetwise Owlbear extension project.
