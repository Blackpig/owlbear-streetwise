# Streetwise Dice Roller POC - Visual Guide

## UI Layout Overview

```
┌─────────────────────────────────────────────────────────────┐
│                                                               │
│                    STREETWISE                                 │
│            Year Zero Engine - Victorian Street Urchins        │
│═══════════════════════════════════════════════════════════════│
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │ Scene Strain Points: [5]         [Reset Scene]      │    │
│  │ (Green=Safe, Yellow=Moderate, Orange=High, Red=Crit) │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Attribute: [3]  Skill: [2]  Modifier: [0]          │    │
│  │                                                      │    │
│  │  ☑ Can Push Twice (Talent)                          │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  Attribute (3) + Skill (2) + Strain (5) = 10 dice            │
│                                                               │
│  [  Roll Dice  ]  [  Push Roll  ]                            │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │              SCENE PANIC!                           │    │
│  │  Roll: 4 + Strain 5 = 9                            │    │
│  │  Major Complication. You have been spotted...      │    │
│  │  +1 additional Scene Strain                         │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Roll Result:                                       │    │
│  │  ┌───────────────────────────────────────────────┐ │    │
│  │  │ PUSHED ROLL                                   │ │    │
│  │  └───────────────────────────────────────────────┘ │    │
│  │                                                      │    │
│  │  Regular Dice (5):                                  │    │
│  │  [4] [6] [2] [1] [5]                               │    │
│  │   ^success  ^bane                                  │    │
│  │                                                      │    │
│  │  Strain Dice (5):                                   │    │
│  │  [3] [1] [6] [2] [4]                               │    │
│  │      ^bane ^success                                │    │
│  │                                                      │    │
│  │  Result: 2 Successes                               │    │
│  │  Banes: 2 total (1 on Strain dice!)               │    │
│  │  Scene Strain: +2 Strain Points                    │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  Recent Rolls:                                                │
│  • Pool: 5 regular + 5 strain → 2 successes, 2 banes (PUSHED)│
│  • Pool: 5 regular + 3 strain → 1 success                    │
│  • Pool: 5 regular + 2 strain → 3 successes                  │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## Color Coding

### Dice Colors
- **Regular Dice**: Cream/Ivory background (#E8DCC8)
  - Border: Brown (#8B7355)
  - Text: Dark ink (#2B2520)

- **Strain Dice**: Crimson background (#B85450)
  - Border: Dark red (#7A0000)
  - Text: White

### Success/Bane Highlights
- **Success (6)**: Green glow and border
  - Regular: Light green background
  - Strain: Lighter red background
  
- **Bane (1)**: Red glow and border
  - Regular: Pink background
  - Strain: Dark red background with pulse animation

### Scene Strain Indicator
- **0-3 (Safe)**: Green (#2D5016)
- **4-6 (Low)**: Light green (#558B2F)
- **7-9 (Medium)**: Orange (#F57C00)
- **10-12 (High)**: Dark orange (#D84315)
- **13+ (Critical)**: Deep red (#7A0000) with pulse

## Key Interactions

### 1. Initial Roll
```
User Action: Click "Roll Dice" button
System Response:
  - Rolls Attribute + Skill + Modifier dice (regular)
  - Rolls Scene Strain dice (strain)
  - Displays all results with visual distinction
  - Counts successes and banes
  - Shows "Push Roll" button
```

### 2. Push Roll
```
User Action: Click "Push Roll" button
System Response:
  - Keeps all 6s and 1s from previous roll
  - Rerolls all other dice (2-5)
  - Combines results from both rolls
  - Counts TOTAL banes (original + pushed)
  - Updates Scene Strain by total banes
  - Checks for Scene Panic if Strain dice have banes
  - Disables Push button (unless talent allows second push)
```

### 3. Scene Panic Trigger
```
Condition: Banes appear on Strain dice during a roll
System Response:
  - Rolls d6
  - Adds current Scene Strain to roll
  - Looks up result in Scene Panic table
  - Displays dramatic alert with effect
  - Applies additional Strain if indicated
  - Updates Scene Strain total
```

### 4. Reset Scene
```
User Action: Click "Reset Scene" button
System Response:
  - Sets Scene Strain to 0
  - Clears any panic alerts
  - Clears current roll display
  - Ready for new scene
```

## Dice Display Details

### Individual Die
```
┌─────┐
│  6  │  ← Success: green border, light background
└─────┘

┌─────┐
│  1  │  ← Bane: red border, pink/dark red background
└─────┘

┌─────┐
│  4  │  ← Normal: standard colors
└─────┘
```

### Die Size
- 48x48 pixels
- Large, readable numbers (24px font)
- Clear visual distinction between types
- Hover effect: slight scale increase

## Summary Display

```
┌─────────────────────────────────────────┐
│ Result: 2 Successes  ✓                 │  ← Green border/background
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ Result: FAILED  ✗                      │  ← Red border/background
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ Banes: 3 total (2 on Strain dice!)     │  ← Orange with warning pulse
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ Scene Strain: +3 Strain Points          │  ← Red background
└─────────────────────────────────────────┘
```

## Responsive Behavior

### Desktop (>800px)
- Single column layout
- All controls in one row
- Dice displayed in flowing grid
- Maximum width: 800px centered

### Tablet (400-800px)
- Controls wrap to multiple rows
- Dice grid adjusts to available width
- Buttons stack if needed

### Mobile (<400px)
- Vertical layout for all controls
- Dice wrap to fit screen
- Touch-friendly button sizes (min 44px)
- Strain tracker moves to top

## Accessibility Features

- **Keyboard Navigation**: All inputs accessible via tab
- **Focus Indicators**: Clear visual focus states
- **Screen Reader Labels**: All inputs properly labeled
- **Color + Text**: Never rely on color alone
- **Large Touch Targets**: Minimum 44x44px

## Victorian Aesthetic Elements

1. **Typography**:
   - Headers: Georgia serif
   - Body: Georgia serif
   - Monospace: Courier New (for roll history)

2. **Color Palette**:
   - Parchment: #F4E8D0
   - Ink: #2B2520
   - Crimson: #8B0000
   - Brass: #B5A642

3. **Visual Details**:
   - Aged paper texture background
   - Double-line borders for headers
   - Ink splatter aesthetic (subtle)
   - Worn, period-appropriate buttons

4. **Shadows & Depth**:
   - Subtle drop shadows
   - Raised button effect
   - Layered paper feel

## Animation Details

### On Roll
- Dice appear instantly (no lengthy animation in POC)
- Success/bane highlights pulse once
- Scene Strain counter animates value change

### Scene Panic
- Alert shakes left-right briefly
- Red color pulses
- Strain indicator flashes

### Strain Level Critical
- Continuous pulse animation
- Glow effect around number
- More intense at higher values

## Testing Checklist

Visual verification:
- [ ] Regular dice are cream-colored
- [ ] Strain dice are crimson
- [ ] 6s have green highlights
- [ ] 1s have red highlights
- [ ] Scene Strain shows correct color for level
- [ ] Pushed rolls show badge
- [ ] Scene Panic alert is dramatic and visible
- [ ] Roll history updates correctly
- [ ] Buttons enable/disable appropriately
- [ ] Layout works on mobile
- [ ] Typography is readable
- [ ] Victorian aesthetic feels appropriate

## Future Enhancements

Visual improvements for full extension:
- Dice roll animation (tumbling effect)
- Sound effects (dice clatter, success chime)
- Particle effects (success sparkles, bane smoke)
- Character portrait integration
- Skill list with quick-roll buttons
- Conditions tracker overlay
- Talent tooltip descriptions
- GM screen with all player sheets
