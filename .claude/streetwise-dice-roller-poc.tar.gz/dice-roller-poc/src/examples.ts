// Streetwise Dice Roller - Example Usage & Test Cases

import { 
  performRoll, 
  pushRoll, 
  checkScenePanic, 
  calculateNewStrain,
  formatRollResult 
} from './utils/diceRoller';

/**
 * Example 1: Basic Roll
 * Character with Strength 3, Scrap 2, no modifier, no strain
 */
export function exampleBasicRoll() {
  console.log('=== Example 1: Basic Roll ===');
  
  const roll = performRoll({
    attribute: 3,
    skill: 2,
    modifier: 0,
    strainPoints: 0
  });
  
  console.log('Dice Pool: 5 regular dice');
  console.log('Regular Results:', roll.results.regular);
  console.log('Successes:', roll.successes);
  console.log('Banes:', roll.totalBanes);
  console.log('Formatted:', formatRollResult(roll));
  console.log('---\n');
  
  return roll;
}

/**
 * Example 2: Roll with Scene Strain
 * Same character but Scene Strain is at 3
 */
export function exampleRollWithStrain() {
  console.log('=== Example 2: Roll with Scene Strain ===');
  
  const roll = performRoll({
    attribute: 3,
    skill: 2,
    modifier: 0,
    strainPoints: 3
  });
  
  console.log('Dice Pool: 5 regular + 3 strain dice');
  console.log('Regular Results:', roll.results.regular);
  console.log('Strain Results:', roll.results.strain);
  console.log('Successes:', roll.successes);
  console.log('Regular Banes:', roll.regularBanes);
  console.log('Strain Banes:', roll.strainBanes);
  console.log('Formatted:', formatRollResult(roll));
  console.log('---\n');
  
  return roll;
}

/**
 * Example 3: Pushing a Roll
 * Make initial roll, then push it
 */
export function examplePushRoll() {
  console.log('=== Example 3: Pushing a Roll ===');
  
  // Initial roll
  const initialRoll = performRoll({
    attribute: 3,
    skill: 2,
    modifier: 0,
    strainPoints: 2
  });
  
  console.log('INITIAL ROLL:');
  console.log('Regular Results:', initialRoll.results.regular);
  console.log('Strain Results:', initialRoll.results.strain);
  console.log('Successes:', initialRoll.successes);
  console.log('Total Banes:', initialRoll.totalBanes);
  console.log('');
  
  // Push the roll
  const pushedRoll = pushRoll(initialRoll);
  
  console.log('PUSHED ROLL:');
  console.log('Regular Results:', pushedRoll.results.regular);
  console.log('Strain Results:', pushedRoll.results.strain);
  console.log('Successes:', pushedRoll.successes);
  console.log('Total Banes (from both rolls):', pushedRoll.totalBanes);
  console.log('');
  
  // Calculate new strain
  const currentStrain = 2;
  const newStrain = calculateNewStrain(currentStrain, pushedRoll);
  console.log('Scene Strain Update:', currentStrain, '→', newStrain);
  console.log('Formatted:', formatRollResult(pushedRoll));
  console.log('---\n');
  
  return { initialRoll, pushedRoll, newStrain };
}

/**
 * Example 4: Scene Panic
 * Simulate a roll with Strain dice showing banes
 */
export function exampleScenePanic() {
  console.log('=== Example 4: Scene Panic ===');
  
  // Create a mock roll with strain banes
  const roll = performRoll({
    attribute: 3,
    skill: 2,
    modifier: 0,
    strainPoints: 5
  });
  
  // Force at least one strain bane for demonstration
  // (In real usage, this happens naturally during rolls)
  if (roll.strainBanes === 0) {
    console.log('(No Strain banes in this roll - Scene Panic would not trigger)');
  } else {
    console.log('⚠️ STRAIN BANES DETECTED! ⚠️');
    console.log('Strain Banes:', roll.strainBanes);
    
    const currentStrain = 5;
    const panicResult = checkScenePanic(roll, currentStrain);
    
    if (panicResult.triggered) {
      console.log('');
      console.log('SCENE PANIC TRIGGERED!');
      console.log('Panic Roll:', panicResult.roll);
      console.log('Current Strain:', currentStrain);
      console.log('Total:', panicResult.total);
      console.log('Effect:', panicResult.effect);
      
      if (panicResult.strainIncrease && panicResult.strainIncrease > 0) {
        console.log('Additional Strain:', '+' + panicResult.strainIncrease);
        console.log('New Strain Total:', currentStrain + panicResult.strainIncrease + roll.totalBanes);
      }
    }
  }
  
  console.log('---\n');
  return roll;
}

/**
 * Example 5: Double Push (with Talent)
 * Push a roll twice using a talent
 */
export function exampleDoublePush() {
  console.log('=== Example 5: Double Push (Talent) ===');
  
  // Initial roll
  const initialRoll = performRoll({
    attribute: 2,
    skill: 1,
    modifier: 0,
    strainPoints: 1,
    canPushTwice: true
  });
  
  console.log('INITIAL ROLL:');
  console.log('Results:', initialRoll.results.regular);
  console.log('Successes:', initialRoll.successes);
  console.log('Can Push:', initialRoll.canPush);
  console.log('');
  
  // First push
  const firstPush = pushRoll(initialRoll, true);
  console.log('FIRST PUSH:');
  console.log('Results:', firstPush.results.regular);
  console.log('Successes:', firstPush.successes);
  console.log('Can Push Again:', firstPush.canPush);
  console.log('');
  
  // Second push (only if talent allows)
  if (firstPush.canPush) {
    const secondPush = pushRoll(firstPush, true);
    console.log('SECOND PUSH:');
    console.log('Results:', secondPush.results.regular);
    console.log('Successes:', secondPush.successes);
    console.log('Total Banes (all three rolls):', secondPush.totalBanes);
    console.log('Can Push Again:', secondPush.canPush);
  }
  
  console.log('---\n');
}

/**
 * Example 6: Edge Case - Negative Dice Pool
 * Character with low stats and penalties
 */
export function exampleNegativePool() {
  console.log('=== Example 6: Negative Dice Pool ===');
  
  const roll = performRoll({
    attribute: 1,
    skill: 0,
    modifier: -2,
    strainPoints: 0
  });
  
  console.log('Calculation: 1 + 0 + (-2) = -1');
  console.log('Actual Dice Pool:', roll.regularDice, '(minimum enforced)');
  console.log('Results:', roll.results.regular);
  console.log('Formatted:', formatRollResult(roll));
  console.log('---\n');
  
  return roll;
}

/**
 * Run all examples
 */
export function runAllExamples() {
  console.log('\n🎲 STREETWISE DICE ROLLER - EXAMPLES 🎲\n');
  
  exampleBasicRoll();
  exampleRollWithStrain();
  examplePushRoll();
  exampleScenePanic();
  exampleDoublePush();
  exampleNegativePool();
  
  console.log('✅ All examples complete!\n');
}

/**
 * Test specific game scenarios
 */
export function testGameScenarios() {
  console.log('\n🎮 GAME SCENARIO TESTS 🎮\n');
  
  // Scenario 1: Desperate escape
  console.log('Scenario 1: Desperate Escape');
  console.log('A Street Nose tries to Scramble away from pursuing Peelers');
  console.log('Agility 4 + Scramble 3, High Scene Strain (7)');
  const escapeRoll = performRoll({
    attribute: 4,
    skill: 3,
    modifier: 0,
    strainPoints: 7
  });
  console.log('Dice Pool: 7 regular + 7 strain = 14 dice!');
  console.log('Successes:', escapeRoll.successes);
  console.log('Result:', escapeRoll.successes > 0 ? '✅ ESCAPED!' : '❌ CAUGHT!');
  console.log('');
  
  // Scenario 2: Delicate lockpicking
  console.log('Scenario 2: Delicate Lockpicking');
  console.log('An Artful Dodge tries to Burgle a lock');
  console.log('Wits 5 + Burgle 3, Low Strain (1)');
  const lockRoll = performRoll({
    attribute: 5,
    skill: 3,
    modifier: 0,
    strainPoints: 1
  });
  console.log('Successes:', lockRoll.successes);
  if (lockRoll.successes === 0) {
    console.log('Failed! Pushing the roll...');
    const pushedLock = pushRoll(lockRoll);
    console.log('Pushed Successes:', pushedLock.successes);
    console.log('New Strain:', 1 + pushedLock.totalBanes);
  }
  console.log('');
  
  // Scenario 3: Brawl with a thug
  console.log('Scenario 3: Brawling');
  console.log('A Brickyard Pug tries to Scrap with a thug');
  console.log('Strength 6 + Scrap 3, Moderate Strain (4)');
  const brawlRoll = performRoll({
    attribute: 6,
    skill: 3,
    modifier: 0,
    strainPoints: 4
  });
  console.log('Successes:', brawlRoll.successes);
  console.log('Extra successes can be spent on: Extra Damage, Disarm, Knock Prone, etc.');
  console.log('');
  
  console.log('---\n');
}

// Uncomment to run examples in console:
// runAllExamples();
// testGameScenarios();
