import React, { useState } from 'react';
import { DiceRoll, RollParameters, ScenePanicResult } from '../types/dice';
import { 
  performRoll, 
  pushRoll, 
  checkScenePanic, 
  calculateNewStrain,
  formatRollResult 
} from '../utils/diceRoller';
import { DiceDisplayFull } from './DiceDisplay';
import './DiceRoller.css';

export const DiceRoller: React.FC = () => {
  // Roll parameters
  const [attribute, setAttribute] = useState(3);
  const [skill, setSkill] = useState(2);
  const [modifier, setModifier] = useState(0);
  const [strainPoints, setStrainPoints] = useState(0);
  const [canPushTwice, setCanPushTwice] = useState(false);
  
  // Roll state
  const [currentRoll, setCurrentRoll] = useState<DiceRoll | null>(null);
  const [panicResult, setPanicResult] = useState<ScenePanicResult | null>(null);
  const [rollHistory, setRollHistory] = useState<string[]>([]);
  
  const handleRoll = () => {
    const params: RollParameters = {
      attribute,
      skill,
      modifier,
      strainPoints,
      canPushTwice
    };
    
    const roll = performRoll(params);
    setCurrentRoll(roll);
    setPanicResult(null);
    
    // Add to history
    const historyEntry = formatRollResult(roll);
    setRollHistory(prev => [historyEntry, ...prev].slice(0, 5));
  };
  
  const handlePush = () => {
    if (!currentRoll || !currentRoll.canPush) return;
    
    const pushedRoll = pushRoll(currentRoll, canPushTwice);
    setCurrentRoll(pushedRoll);
    
    // Update strain
    const newStrain = calculateNewStrain(strainPoints, pushedRoll);
    setStrainPoints(newStrain);
    
    // Check for scene panic
    const panic = checkScenePanic(pushedRoll, strainPoints);
    setPanicResult(panic);
    
    if (panic.triggered && panic.strainIncrease) {
      setStrainPoints(prev => prev + panic.strainIncrease!);
    }
    
    // Add to history
    const historyEntry = formatRollResult(pushedRoll);
    setRollHistory(prev => [historyEntry, ...prev].slice(0, 5));
  };
  
  const handleResetStrain = () => {
    setStrainPoints(0);
    setPanicResult(null);
  };
  
  const totalDice = Math.max(1, attribute + skill + modifier) + strainPoints;
  
  return (
    <div className="dice-roller">
      <div className="dice-roller__header">
        <h1>Streetwise Dice Roller</h1>
        <p className="subtitle">Year Zero Engine - Victorian Street Urchins</p>
      </div>
      
      {/* Scene Strain Tracker */}
      <div className="strain-tracker">
        <div className="strain-tracker__display">
          <span className="strain-tracker__label">Scene Strain Points:</span>
          <span className={`strain-tracker__value strain-tracker__value--${
            strainPoints === 0 ? 'safe' :
            strainPoints <= 3 ? 'low' :
            strainPoints <= 6 ? 'medium' :
            strainPoints <= 9 ? 'high' : 'critical'
          }`}>
            {strainPoints}
          </span>
        </div>
        <button 
          className="strain-tracker__reset"
          onClick={handleResetStrain}
          disabled={strainPoints === 0}
        >
          Reset Scene
        </button>
      </div>
      
      {/* Roll Parameters */}
      <div className="roll-params">
        <div className="param-group">
          <label htmlFor="attribute">Attribute</label>
          <input
            id="attribute"
            type="number"
            min="0"
            max="10"
            value={attribute}
            onChange={(e) => setAttribute(parseInt(e.target.value) || 0)}
          />
        </div>
        
        <div className="param-group">
          <label htmlFor="skill">Skill</label>
          <input
            id="skill"
            type="number"
            min="0"
            max="10"
            value={skill}
            onChange={(e) => setSkill(parseInt(e.target.value) || 0)}
          />
        </div>
        
        <div className="param-group">
          <label htmlFor="modifier">Modifier</label>
          <input
            id="modifier"
            type="number"
            min="-5"
            max="5"
            value={modifier}
            onChange={(e) => setModifier(parseInt(e.target.value) || 0)}
          />
        </div>
        
        <div className="param-group param-group--checkbox">
          <label htmlFor="canPushTwice">
            <input
              id="canPushTwice"
              type="checkbox"
              checked={canPushTwice}
              onChange={(e) => setCanPushTwice(e.target.checked)}
            />
            Can Push Twice (Talent)
          </label>
        </div>
      </div>
      
      {/* Dice Pool Summary */}
      <div className="dice-pool-summary">
        <div className="pool-calculation">
          <span>Attribute ({attribute})</span>
          <span>+</span>
          <span>Skill ({skill})</span>
          {modifier !== 0 && (
            <>
              <span>{modifier > 0 ? '+' : ''}</span>
              <span>Modifier ({modifier})</span>
            </>
          )}
          {strainPoints > 0 && (
            <>
              <span>+</span>
              <span className="strain-highlight">Strain ({strainPoints})</span>
            </>
          )}
          <span>=</span>
          <span className="pool-total">{totalDice} dice</span>
        </div>
      </div>
      
      {/* Action Buttons */}
      <div className="action-buttons">
        <button 
          className="btn btn--primary btn--large"
          onClick={handleRoll}
        >
          Roll Dice
        </button>
        
        {currentRoll && currentRoll.canPush && (
          <button 
            className="btn btn--warning btn--large"
            onClick={handlePush}
          >
            Push Roll {currentRoll.pushed && canPushTwice ? '(2nd Push)' : ''}
          </button>
        )}
      </div>
      
      {/* Scene Panic Alert */}
      {panicResult && panicResult.triggered && (
        <div className="scene-panic-alert">
          <h3>⚠️ SCENE PANIC! ⚠️</h3>
          <p className="panic-roll">
            Roll: {panicResult.roll} + Strain {strainPoints - (panicResult.strainIncrease || 0)} = {panicResult.total}
          </p>
          <p className="panic-effect">{panicResult.effect}</p>
          {panicResult.strainIncrease! > 0 && (
            <p className="panic-strain">+{panicResult.strainIncrease} additional Scene Strain</p>
          )}
        </div>
      )}
      
      {/* Current Roll Display */}
      {currentRoll && (
        <div className="current-roll">
          <h3>Roll Result</h3>
          <DiceDisplayFull
            regularDice={currentRoll.results.regular}
            strainDice={currentRoll.results.strain}
            successes={currentRoll.successes}
            regularBanes={currentRoll.regularBanes}
            strainBanes={currentRoll.strainBanes}
            pushed={currentRoll.pushed}
          />
          
          {currentRoll.pushed && currentRoll.totalBanes > 0 && (
            <div className="strain-warning">
              Scene Strain increased by {currentRoll.totalBanes} (from {strainPoints - currentRoll.totalBanes} → {strainPoints})
            </div>
          )}
        </div>
      )}
      
      {/* Roll History */}
      {rollHistory.length > 0 && (
        <div className="roll-history">
          <h3>Recent Rolls</h3>
          <ul>
            {rollHistory.map((entry, index) => (
              <li key={index}>{entry}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
