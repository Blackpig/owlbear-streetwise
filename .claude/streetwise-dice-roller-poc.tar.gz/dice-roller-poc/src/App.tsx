import React from 'react';
import { DiceRoller } from './components/DiceRoller';
import './App.css';

function App() {
  return (
    <div className="app">
      <DiceRoller />
    </div>
  );
}

export default App;
